package com.finalexam.apsd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalExamApsdApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalExamApsdApplication.class, args);
    }

}
