package com.finalexam.apsd.controller;

import com.finalexam.apsd.dto.PropertyDTO;
import com.finalexam.apsd.entity.Property;
import com.finalexam.apsd.service.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/property")
public class PropertyController {

    @Autowired
    private PropertyService propertyService;

    @GetMapping("/{state}")
    ResponseEntity<List<Property>> getAllProperites(@PathVariable("state") String state){
        List<Property> list =  this.propertyService.getAllProperites(state);
        return ResponseEntity.ok(list);
    }

    @GetMapping("/list/{state}")
    ResponseEntity<List<Property>> getAllProperty(@PathVariable("state") String state){
        List<Property> list =  this.propertyService.getProperty();
        return ResponseEntity.ok(list);
    }

}
