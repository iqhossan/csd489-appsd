package com.finalexam.apsd.service.Impl;

import com.finalexam.apsd.dto.LeaseResponse;
import com.finalexam.apsd.dto.PropertyDTO;
import com.finalexam.apsd.entity.Lease;
import com.finalexam.apsd.entity.Property;
import com.finalexam.apsd.repository.PropertyRepository;
import com.finalexam.apsd.service.PropertyService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PropertryServiceImpl implements PropertyService {

    @Autowired
    private PropertyRepository repository;

    @Autowired
    private ModelMapper modelMapper;
    
    @Override
    public List<Property> getAllProperites(String state) {
        List<Property> property = this.repository.findPropertyByState(state);

        return property;
    }

    public List<Property> getProperty() {
       return  null;
    }

}
