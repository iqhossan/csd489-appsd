package com.finalexam.apsd.service;

import com.finalexam.apsd.dto.PropertyDTO;
import com.finalexam.apsd.entity.Property;

import java.util.List;

public interface PropertyService {

    List<Property> getAllProperites(String state);
    List<Property> getProperty();
}
