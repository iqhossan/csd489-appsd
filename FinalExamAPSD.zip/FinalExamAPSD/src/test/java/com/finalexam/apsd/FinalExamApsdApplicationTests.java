package com.finalexam.apsd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalExamApsdApplicationTests {

    @Test
    void contextLoads() {
    }

}
